#include "Device.h"

Device::Device()
{
	this->DeviceName[0] = NULL;
	this->DeviceType[0] = NULL;	
	this->Simulator = FALSE;
	this->portName[0] = NULL;
	//this->terminalSerial = NULL;
	//this->Counter++;
}

Device::Device(const TCHAR *src) 
{
	this->DeviceName[0] = NULL;
	this->DeviceType[0] = NULL;
	this->Simulator = FALSE;
	this->portName[0] = NULL;
	//this->terminalSerial = NULL;
	SetDeviceName(src);
	SetDeviceType(src);
	SetSimulator(src);
}

//BOOL Device::GetDeviceName(TCHAR *dest, const TCHAR *src, UINT SizeinBytes)
//{
//	INT cnt;
//	if (SizeinBytes > MAX_PATH) return FALSE;
//	if (SizeinBytes == NULL) {
//		for (cnt = 0; src[cnt] != NULL; cnt++) {
//			dest[cnt] = src[cnt];
//		}
//	}
//	else {
//		for (cnt = 0; cnt < SizeinBytes; cnt++) {
//			dest[cnt] = src[cnt];
//		}
//	}
//	dest[cnt] = NULL;
//	return TRUE;
//}

BOOL Device::GetDeviceName(TCHAR *dest)
{
	INT cnt;
	for (cnt = 0; this->DeviceName[cnt] != NULL; cnt++) {
		if (cnt >= MAX_PATH) return FALSE;
		dest[cnt] = this->DeviceName[cnt];
	}
	dest[cnt] = NULL;
	return TRUE;
}

//BOOL Device::GetDeviceType(TCHAR *dest, const TCHAR *src, UINT SizeinBytes)
//{
//	INT cnt;
//	if (SizeinBytes > DEVICETYPE_MAX) return FALSE;
//	if (SizeinBytes == NULL) {
//		for (cnt = 0; src[cnt] != NULL; cnt++) {
//			dest[cnt] = src[cnt];
//		}
//	}
//	else {
//		for (cnt = 0; cnt < SizeinBytes; cnt++) {
//			dest[cnt] = src[cnt];
//		}
//	}
//	dest[cnt] = NULL;
//	return TRUE;
//}

BOOL Device::GetDeviceType(TCHAR *dest)
{
	INT cnt;
	for (cnt = 0; this->DeviceType[cnt] != NULL; cnt++) {
		if (cnt >= DEVICETYPE_MAX) return FALSE;
		dest[cnt] = this->DeviceType[cnt];
	}
	dest[cnt] = NULL;
	return TRUE;
}

BOOL Device::GetSimulator()
{
	return this->Simulator;
}

//BOOL Device::SetSerialCommPtr(SerialComm SerialPort)
//{
//	if (SerialPort.IsConnected() == TRUE) return FALSE;
//
//	this->terminalSerial = &SerialPort;
//}

//BOOL Device::SetDeviceName(TCHAR *dest, const TCHAR *src)
//{
//	int cnt;
//	int cnt2;
//	for (cnt = 0; src[cnt + 11] != NULL; cnt++) {
//		if (cnt >= 1012) break;
//		if (src[cnt] == 'D' && src[cnt + 1] == 'e' && src[cnt + 2] == 'v' && src[cnt + 3] == 'i'
//			&& src[cnt + 4] == 'c' && src[cnt + 5] == 'e' && src[cnt + 6] == 'N' && src[cnt + 7] == 'a'
//			&& src[cnt + 8] == 'm' && src[cnt + 9] == 'e' && src[cnt + 10] == '=' && src[cnt + 11] != ';') {
//			for (cnt2 = 0; src[cnt + 11 + cnt2]!=';'; cnt2++) {
//				if ((src[cnt + 11 + cnt2] == NULL) || (cnt + 11 + cnt2 >= 1024)) return FALSE;
//				dest[cnt2] = src[cnt + 11 + cnt2];
//			}
//			dest[cnt2] = NULL;
//			break;
//		}
//	}
//	return TRUE;
//}

BOOL Device::GetPortName(TCHAR *dest)
{
	INT cnt;
	for (cnt = 0; this->portName[cnt] != NULL; cnt++) {
		if (cnt >= MAX_PATH) return FALSE;
		dest[cnt] = this->portName[cnt];
	}
	dest[cnt] = NULL;
	return TRUE;
}

BOOL Device::SetDeviceName(const TCHAR *src)
{
	int cnt;
	int cnt2;
	for (cnt = 0; src[cnt + 11] != NULL; cnt++) {
		if (cnt >= 1012) break;
		if (src[cnt] == 'D' && src[cnt + 1] == 'e' && src[cnt + 2] == 'v' && src[cnt + 3] == 'i'
			&& src[cnt + 4] == 'c' && src[cnt + 5] == 'e' && src[cnt + 6] == 'N' && src[cnt + 7] == 'a'
			&& src[cnt + 8] == 'm' && src[cnt + 9] == 'e' && src[cnt + 10] == '=' && src[cnt + 11] != ';') {
			for (cnt2 = 0; src[cnt + 11 + cnt2] != ';'; cnt2++) {
				if ((src[cnt + 11 + cnt2] == NULL) || (cnt + 11 + cnt2 >= 1024)) return FALSE;
				this->DeviceName[cnt2] = src[cnt + 11 + cnt2];
			}
			this->DeviceName[cnt2] = NULL;
			break;
		}
	}
	return TRUE;
}

//BOOL Device::SetDeviceType(TCHAR *dest, const TCHAR *src)
//{
//	int cnt;
//	int cnt2;
//	for (cnt = 0; src[cnt + 11] != NULL; cnt++) {
//		if (cnt >= 1012) break;
//		if (src[cnt] == 'D' && src[cnt + 1] == 'e' && src[cnt + 2] == 'v' && src[cnt + 3] == 'i'
//			&& src[cnt + 4] == 'c' && src[cnt + 5] == 'e' && src[cnt + 6] == 'T' && src[cnt + 7] == 'y'
//			&& src[cnt + 8] == 'p' && src[cnt + 9] == 'e' && src[cnt + 10] == '=' && src[cnt + 11] != ';') {
//			for (cnt2 = 0; src[cnt + 11 + cnt2] != ';'; cnt2++) {
//				if ((src[cnt + 11 + cnt2] == NULL) || (cnt + 11 + cnt2 >= 1024)) return FALSE;
//				dest[cnt2] = src[cnt + 11 + cnt2];
//			}
//			dest[cnt2] = NULL;
//			break;
//		}
//	}
//	return TRUE;
//}

BOOL Device::SetDeviceType(const TCHAR *src)
{
	int cnt;
	int cnt2;
	for (cnt = 0; src[cnt + 11] != NULL; cnt++) {
		if (cnt >= 1012) break;
		if (src[cnt] == 'D' && src[cnt + 1] == 'e' && src[cnt + 2] == 'v' && src[cnt + 3] == 'i'
			&& src[cnt + 4] == 'c' && src[cnt + 5] == 'e' && src[cnt + 6] == 'T' && src[cnt + 7] == 'y'
			&& src[cnt + 8] == 'p' && src[cnt + 9] == 'e' && src[cnt + 10] == '=' && src[cnt + 11] != ';') {
			for (cnt2 = 0; src[cnt + 11 + cnt2] != ';'; cnt2++) {
				if ((src[cnt + 11 + cnt2] == NULL) || (cnt + 11 + cnt2 >= 1024)) return FALSE;
				this->DeviceType[cnt2] = src[cnt + 11 + cnt2];
			}
			this->DeviceType[cnt2] = NULL;
			break;
		}
	}
	return TRUE;
}

BOOL Device::SetSimulator(const TCHAR *src)
{
	int cnt;
	for (cnt = 0; src[cnt + 10] != NULL; cnt++) {
		if (cnt >= 1013) return FALSE;
		if (src[cnt] == 'S' && src[cnt + 1] == 'i' && src[cnt + 2] == 'm' && src[cnt + 3] == 'u'
			&& src[cnt + 4] == 'l' && src[cnt + 5] == 'a' && src[cnt + 6] == 't' && src[cnt + 7] == 'o'
			&& src[cnt + 8] == 'r' && src[cnt + 9] == '=' && src[cnt + 10] != ';') {
			if (src[cnt + 10] == '0') this->Simulator = FALSE;
			else if (src[cnt + 10] == '1') this->Simulator = TRUE;
			else return FALSE;		
		}
	}
	return TRUE;
}

BOOL Device::SetPortName(const TCHAR *src)
{
	INT cnt;
	for (cnt = 0; src[cnt] != NULL; cnt++) {
		if (cnt >= MAX_PATH) return FALSE;
		this->portName[cnt] = src[cnt];
	}
	this->portName[cnt] = NULL;
	return TRUE;
}

BOOL Device::InitPortName()
{
	this->portName[0] = NULL;
	return TRUE;
}

Device * Device::GetThisPointer()
{
	return this;
}

Device::~Device()
{
}
