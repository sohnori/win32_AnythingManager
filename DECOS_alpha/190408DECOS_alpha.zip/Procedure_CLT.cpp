#include "Procedure_CLT.h"
#include "SerialComm.h"
#include "SerialCommControl.h"
#include "MyFunc.h"
#include "Device.h"
#include "DeviceControl.h"
#include "resource.h"


#define DEVICETEXTXPOS	120
#define DEVICETEXTYPOS	280
#define DEVICETEXTYRATIO	55

extern HINSTANCE g_hInst;

extern DeviceControl Device;
extern SerialCommControl SerialPort;

// ���ϵ� ������ �ڵ�
extern HWND hCLT, hCRT, hCRB , hBtnTestA;

HWND hWndSerial;
static HWND hList, hEdit, hBtnAdd, hBtnAdd2, hBtnRemove, hBtnRemove2,
	hComboTerminal, hBtnConn, hBtnDisConn;

static struct tagDCBDlgInfo DCBDlgInfo;

const TCHAR textDeviceName[] = TEXT("DeviceName=");
const TCHAR textDeviceType[] = TEXT("DeviceType=");
const TCHAR textSimulator[] = TEXT("Simulator=");
const TCHAR textHostPC[] = TEXT("HostPC");
const TCHAR textCoordi[] = TEXT("Coordinator_IoT");
const TCHAR textInverter[] = TEXT("Inverter");
const TCHAR textetc[] = TEXT("etc_Device");


// ������ ���ϵ��� �޽��� ���ν��� ó�� �Լ�
INT OnCreateChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnTimerChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnSizeChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnCommandChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnPaintChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnUser1ChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam);

// ��ġ �߰� ��ȭ���� �޽��� ���ν��� ó�� �Լ�
INT OnInitDialogAddDeviceProc(HWND hDlg, WPARAM wParam, LPARAM lParam);
INT OnCommandAddDeviceProc(HWND hDlg, WPARAM wParam, LPARAM lParam);

// ��� ���� ��ȭ���� �޽��� ���ν��� ó�� �Լ�
INT OnInitDialogConnectDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam);
INT OnCommandConnectDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam);

// �ø��� ��� ��ȭ���� �޽��� ���ν��� ó�� �Լ�
INT OnInitDialogSerialDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam);
INT OnCommandSerialDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam);

// ������ ���ϵ��� �޽��� ���ν���
LRESULT CALLBACK ChildLTProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{		
	switch (iMessage) {
	case WM_CREATE: return OnCreateChildLTProc(hWnd, wParam, lParam);
	case WM_SIZE: OnSizeChildLTProc(hWnd, wParam, lParam); return 0;
	case WM_COMMAND: OnCommandChildLTProc(hWnd, wParam, lParam); break;
	case WM_PAINT: OnPaintChildLTProc(hWnd, wParam, lParam); return 0;
	case WM_USER+1: OnUser1ChildLTProc(hWnd, wParam, lParam); return 0; // refresh serial list
	case WM_TIMER: OnTimerChildLTProc(hWnd, wParam, lParam); return 0;
	/*case WM_NCHITTEST: // Ÿ��Ʋ�� ���� �۾����� �巡�� �̵� ����
	nHit = DefWindowProc(hWnd, iMessage, wParam, lParam);
	if (nHit == HTCLIENT)
	nHit = HTCAPTION;
	return nHit;*/	
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

// ��ġ�߰� ��ȭ���� �޽��� ���ν���
BOOL CALLBACK AddDeviceDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
	case WM_INITDIALOG: OnInitDialogAddDeviceProc(hDlg, wParam, lParam); return TRUE;
	case WM_COMMAND: OnCommandAddDeviceProc(hDlg, wParam, lParam); return TRUE;
	}
	return FALSE;
}

// �͹̳� �߰� ��ȭ���� �޽��� ���ν���
BOOL CALLBACK ConnectDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
	case WM_INITDIALOG: OnInitDialogConnectDlgProc(hDlg, wParam, lParam); return TRUE;
	case WM_COMMAND: OnCommandConnectDlgProc(hDlg, wParam, lParam); break;
	}
	return FALSE;
}

// �͹̳� �߰� ��ȭ���� ���� �ø��� ��Ʈ �� ��ȭ���� �޽��� ���ν���
BOOL CALLBACK SerialDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam)
{		
	switch (iMessage) {
	case WM_INITDIALOG:	OnInitDialogSerialDlgProc(hDlg, wParam, lParam); return TRUE;
	case WM_COMMAND: OnCommandSerialDlgProc(hDlg, wParam, lParam); return TRUE;
	}
	return FALSE;
}

INT OnCreateChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{	
	INT FileCnt;
	TCHAR fname[MAX_PATH];
	hList = CreateWindow(TEXT("listbox"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | LBS_NOTIFY | LBS_NOINTEGRALHEIGHT | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, (HMENU)0, g_hInst, NULL);
	//SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)TEXT("����Ʈ �ڽ�"));
	/*hEdit = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
		210, 10, 90, 25, hWnd, (HMENU)1, g_hInst, NULL);*/
	hBtnAdd = CreateWindow(TEXT("button"), TEXT("��ġ�߰�"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		180, 10, 100, 25, hWnd, (HMENU)2, g_hInst, NULL);
	hBtnAdd2 = CreateWindow(TEXT("button"), TEXT("�͹̳��߰�"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		180, 40, 100, 25, hWnd, (HMENU)3, g_hInst, NULL);
	hBtnRemove = CreateWindow(TEXT("button"), TEXT("��ġ����"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		180, 70, 100, 25, hWnd, (HMENU)4, g_hInst, NULL);
	hBtnRemove2 = CreateWindow(TEXT("button"), TEXT("�͹̳�����"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		180, 100, 100, 25, hWnd, (HMENU)5, g_hInst, NULL);
	hComboTerminal = CreateWindow(TEXT("combobox"), NULL, WS_CHILD | WS_VISIBLE | CBS_DROPDOWNLIST | WS_VSCROLL,
		180, 130, 100, 100, hWnd, (HMENU)6, g_hInst, NULL);
	hBtnConn = CreateWindow(TEXT("button"), TEXT("����"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		180, 230, 40, 25, hWnd, (HMENU)7, g_hInst, NULL);
	hBtnDisConn = CreateWindow(TEXT("button"), TEXT("����"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		230, 230, 40, 25, hWnd, (HMENU)8, g_hInst, NULL);
	//SendMessage(hComboTerminal, CB_ADDSTRING, 0, (LPARAM)TEXT("test1"));
	FileCnt = FindDeviceFile(hList, fname);
	Device.InitSetDevices(fname, FileCnt);
	SetTimer(hWnd, 2, 1000, NULL);
	return 0;	
}

INT OnTimerChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	static TCHAR sTime[128];
	HDC hDc;
	SYSTEMTIME st;
	switch (LOWORD(wParam)) {
	case 2:
		GetLocalTime(&st);
		wsprintf(sTime, TEXT("�ð�: %02d:%02d:%02d"), st.wHour, st.wMinute, st.wSecond);
		hDc = GetDC(hWnd);
		TextOut(hDc, 180, 160, sTime, lstrlen(sTime));
		ReleaseDC(hWnd, hDc);
		return 0;
	}
	return 0;
}

INT OnSizeChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	MoveWindow(hList, 10, 10, 160, HIWORD(lParam)/2, TRUE);
	return 0;
}

INT OnCommandChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	//HWND hWndPort;
	INT i;
	INT cnt;
	TCHAR fname[MAX_PATH];
	TCHAR str[MAX_PATH] = "";

	switch (LOWORD(wParam)) {
	case 0: // ���ϸ�� ����Ʈ�ڽ�
		//MessageBox(hWnd, TEXT("fff"), NULL, MB_OK);
		switch (HIWORD(wParam)) {
		case LBN_SELCHANGE:
			i = SendMessage(hList, LB_GETCURSEL, 0, 0);			
			SendMessage(hCRT, WM_USER + 1, (WPARAM)i, 0);
			InvalidateRect(hCLT, NULL, TRUE);
			break;
		}
		break;
	case 2: // ��ġ �߰� ��ư
		//DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DIALOG_ADD), hWnd, AddDeviceDlgProc);
		DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DIALOG_ADD), hWnd, (DLGPROC)AddDeviceDlgProc);
		break;
	case 3: // �͹̳� �߰� ��ư
		//DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DIALOG_CONN), hWnd, ConnectDlgProc);
		DialogBox(g_hInst, MAKEINTRESOURCE(IDD_DIALOG_CONN), hWnd, (DLGPROC)ConnectDlgProc);
		SendMessage(hComboTerminal, CB_RESETCONTENT, 0, 0);
		SerialPort.GetStrTerminals(str);
		for (cnt = 0; str[cnt]!=NULL; cnt++) {
			if (str[cnt] == 'Y') {
				SerialPort.Terminal[cnt]->GetPortName(fname);
				SendMessage(hComboTerminal, CB_ADDSTRING, 0, (LPARAM)fname);
			}			
		}		
		break;
	case 4: // ��ġ ���� ��ư
		// ����Ʈ���� ��ġ���� �� ��ü, ����Ʈ �����ʱ�ȭ		
		i = SendMessage(hList, LB_GETCURSEL, 0, 0);
		if (i == -1) {
			MessageBox(hWnd, TEXT("������ �����Ͻʽÿ�!!"), TEXT("�޽��� �ڽ�"), MB_OK);
			break;
		}
		SendMessage(hList, LB_GETTEXT, (WPARAM)i, (LPARAM)fname);
		if (DeleteFile(fname) != TRUE) {
			MessageBox(hWnd, TEXT("������ ���� �� �����ϴ�!!"), TEXT("�޽��� �ڽ�"), MB_OK);
			break;
		}
		Device.DeleteDevices();
		SendMessage(hList, LB_RESETCONTENT, 0, 0);
		i = FindDeviceFile(hList, fname);
		Device.InitSetDevices(fname, i);
		InvalidateRect(hCLT, NULL, TRUE);
		break;
	case 5: // �͹̳� ���� ��ư
		i = SendMessage(hComboTerminal, CB_GETCURSEL, 0, 0);
		if (i == -1) {
			MessageBox(hWnd, TEXT("�͹̳��� �����Ͻʽÿ�!!"), TEXT("�޽��� �ڽ�"), MB_OK);
			break;
		}
		SendMessage(hComboTerminal, CB_GETLBTEXT, (WPARAM)i, (LPARAM)str);
		SerialPort.GetTerminalIndex(&i, str);
		if (SerialPort.DeleteTerminal(i) == TRUE) {
			i = SendMessage(hComboTerminal, CB_GETCURSEL, 0, 0);
			SendMessage(hComboTerminal, CB_DELETESTRING, (WPARAM)i, 0);
			SendMessage(hCRB, WM_USER + 1, (WPARAM)2, (LPARAM)i);
		}
		InvalidateRect(hCLT, NULL, TRUE);
		break;
	case 6: // �͹̳� ��� �޺��ڽ�
		break;
	case 7: // ���� ��ư : Ȱ��ȭ�Ǿ� �ִ� ��ġ�� �͹̳��� �����Ų��.
		i = SendMessage(hList, LB_GETCURSEL, 0, 0);
		if (i == -1) {
			MessageBox(hWnd, TEXT("������ �����Ͻʽÿ�!!"), TEXT("�޽��� �ڽ�"), MB_OK);
			break;
		}
		i = SendMessage(hComboTerminal, CB_GETCURSEL, 0, 0);
		if (i == -1) {
			MessageBox(hWnd, TEXT("�͹̳��� �����Ͻʽÿ�!!"), TEXT("�޽��� �ڽ�"), MB_OK);
			break;
		}
		SendMessage(hComboTerminal, CB_GETLBTEXT, (WPARAM)i, (LPARAM)str);
		i = SendMessage(hList, LB_GETCURSEL, 0, 0);
		Device.Dev[i]->SetPortName(str);
		InvalidateRect(hCLT, NULL, TRUE);
		break;
	case 8: // ���� ��ư : Ȱ��ȭ�Ǿ� �ִ� ��ġ�� �͹̳��� ������Ų��.
		i = SendMessage(hList, LB_GETCURSEL, 0, 0);
		if (i == -1) {
			MessageBox(hWnd, TEXT("������ �����Ͻʽÿ�!!"), TEXT("�޽��� �ڽ�"), MB_OK);
			break;
		}
		Device.Dev[i]->InitPortName();
		InvalidateRect(hCLT, NULL, TRUE);
		break;
	}
	return 0;
}

INT OnPaintChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	TCHAR str[MAX_PATH];
	INT index;
	INT index2;
	INT Height;
	RECT crt;
	tagDCBDlgInfo DCB;

	hdc = BeginPaint(hWnd, &ps);
	index = SendMessage(hList, LB_GETCURSEL, 0, 0);
	if(index!=-1){
		GetClientRect(hWnd, &crt);
		Height = crt.bottom*DEVICETEXTYRATIO / 100;
		SetTextAlign(hdc, TA_RIGHT);
		//pDev = (Device*)SendMessage(hList, LB_GETITEMDATA, index, 0);
		//pDev->GetDeviceName(str);
		
		//wsprintf(str, TEXT("Device Name : %s"), pDev->GetDeviceName);	
		TextOut(hdc, DEVICETEXTXPOS, Height, TEXT("Device Name   :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +20, TEXT("Device Type   :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +40, TEXT("Terminal Type :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +60, TEXT("Terminal ID   :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +80, TEXT("Port Name     :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +100, TEXT("Baud Rate     :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +120, TEXT("Data Bits     :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +140, TEXT("Parity Bit    :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +160, TEXT("Stop Bit      :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height +180, TEXT("Flow Control  :"), 15);
		TextOut(hdc, DEVICETEXTXPOS, Height + 200, TEXT("Attribute     :"), 15);
		SetTextAlign(hdc, TA_NOUPDATECP);
		Device.Dev[index]->GetDeviceName(str);
		TextOut(hdc, DEVICETEXTXPOS+20, Height, str, lstrlen(str));
		Device.Dev[index]->GetDeviceType(str);		
		TextOut(hdc, DEVICETEXTXPOS+20, Height +20, str, lstrlen(str));
		Device.Dev[index]->GetPortName(str);
		TextOut(hdc, DEVICETEXTXPOS + 20, Height + 80, str, lstrlen(str));
		if (SerialPort.GetTerminalIndex(&index2, str) == TRUE)
		{
			SerialPort.GetTerminalDCBInfo(&DCB, index2);
			_itoa_s(DCB.baudRate, str, 10);
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 100, str, lstrlen(str));
			_itoa_s(DCB.dataBits, str, 10);
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 120, str, lstrlen(str));
			if (DCB.parity == 0) strcpy_s(str, "None");
			else if (DCB.parity == 1) strcpy_s(str, "Odd");
			else if (DCB.parity == 2) strcpy_s(str, "Even");
			else strcpy_s(str, "");
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 140, str, lstrlen(str));
			if (DCB.stopBits == 0) strcpy_s(str, "1");
			else if (DCB.stopBits == 1) strcpy_s(str, "1.5");
			else if (DCB.stopBits == 2) strcpy_s(str, "2");
			else strcpy_s(str, "");
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 160, str, lstrlen(str));
			if (DCB.flowControl == 0) strcpy_s(str, "None");
			else if (DCB.flowControl == 1) strcpy_s(str, "Xon/Xoff");
			else if (DCB.flowControl == 2) strcpy_s(str, "RTS/CTS");
			else strcpy_s(str, "");
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 180, str, lstrlen(str));
		}
		else {
			strcpy_s(str, "");
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 100, str, lstrlen(str));
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 120, str, lstrlen(str));
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 140, str, lstrlen(str));
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 160, str, lstrlen(str));
			TextOut(hdc, DEVICETEXTXPOS + 20, Height + 180, str, lstrlen(str));
		}
		if (Device.Dev[index]->GetSimulator() == TRUE) strcpy_s(str, TEXT("Simulator"));
		else if (Device.Dev[index]->GetSimulator() == FALSE) strcpy_s(str, TEXT("Real Device"));
		else str[0] = NULL;
		TextOut(hdc, DEVICETEXTXPOS + 20, Height + 200, str, lstrlen(str));
	}	
	EndPaint(hWnd, &ps);
	return 0;
}

INT OnUser1ChildLTProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	INT index;
	INT i;
	TCHAR str[MAX_PATH];
	TCHAR count = SendMessage(hComboTerminal, CB_GETCOUNT, 0, 0);
	switch (LOWORD(wParam)) {
	case 1:
		for (index = 0; index < count; index++) {
			if (count > 9) return FALSE;
			SendMessage(hComboTerminal, CB_GETLBTEXT, (WPARAM)index, (LPARAM)str);
			if (SerialPort.GetTerminalIndex(&i, str) != TRUE) {
				SendMessage(hComboTerminal, CB_DELETESTRING, (WPARAM)index, 0);
				SendMessage(hCRB, WM_USER + 1, (WPARAM)2, (LPARAM)index);
			}
		}
	}
	return 0;
}

INT OnInitDialogAddDeviceProc(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DT), CB_ADDSTRING, 0, (LPARAM)textHostPC);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DT), CB_ADDSTRING, 0, (LPARAM)textCoordi);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DT), CB_ADDSTRING, 0, (LPARAM)textInverter);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DT), CB_ADDSTRING, 0, (LPARAM)textetc);
	return TRUE;
}

INT OnCommandAddDeviceProc(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	TCHAR fname[MAX_PATH];
	TCHAR DeviceStr[1024];
	TCHAR AddDeviceInfo[MAX_PATH];
	DWORD dwWritten;
	HANDLE hFile;
	INT i;
	switch (LOWORD(wParam)) {
	case IDOK:
		i = Device.GetObjectCount();
		if (i <= SendMessage(hList, LB_GETCOUNT, 0, 0)) {
			MessageBox(hDlg, TEXT("���̻� ��ġ�� ������ �� �����ϴ�."), TEXT("���"), MB_OK);
			EndDialog(hDlg, IDCANCEL);
			return TRUE;
		}
		GetDlgItemText(hDlg, IDC_EDIT_DN, fname, sizeof(fname));
		strcat_s(fname, TEXT(".dcs"));
		hFile = CreateFile(fname, GENERIC_WRITE, 0, NULL, CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile == INVALID_HANDLE_VALUE) {
			MessageBox(hDlg, TEXT("�̹� �����ϴ� �����Դϴ�."), TEXT("���"), MB_OK);
			CloseHandle(hFile);
			return TRUE;
		}		
		//SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)str);
		strcpy_s(DeviceStr, textDeviceName);
		GetDlgItemText(hDlg, IDC_EDIT_DN, AddDeviceInfo, sizeof(AddDeviceInfo));
		strcat_s(DeviceStr, AddDeviceInfo);
		strcat_s(DeviceStr, TEXT(";"));
		i = SendMessage(GetDlgItem(hDlg, IDC_COMBO_DT), CB_GETCURSEL, 0, 0);
		SendMessage(GetDlgItem(hDlg, IDC_COMBO_DT), CB_GETLBTEXT, (WPARAM)i, (LPARAM)AddDeviceInfo);
		strcat_s(DeviceStr, textDeviceType);
		strcat_s(DeviceStr, AddDeviceInfo);
		strcat_s(DeviceStr, TEXT(";"));
		//WriteFile(hFile, AddDeviceInfo, lstrlen(AddDeviceInfo), &dwWritten, NULL);
		strcat_s(DeviceStr, textSimulator);
		if (IsDlgButtonChecked(hDlg, IDC_CHECK_SIMUL) == TRUE) {
			strcat_s(DeviceStr, TEXT("1;"));
			WriteFile(hFile, DeviceStr, lstrlen(DeviceStr), &dwWritten, NULL);
		}
		else {
			strcat_s(DeviceStr, TEXT("0;"));
			WriteFile(hFile, DeviceStr, lstrlen(DeviceStr), &dwWritten, NULL);
		}
		CloseHandle(hFile);
		Device.DeleteDevices();
		SendMessage(hList, LB_RESETCONTENT, 0, 0);
		i = FindDeviceFile(hList, fname);
		Device.InitSetDevices(fname, i);
		EndDialog(hDlg, IDOK);
		return TRUE;
	case IDCANCEL:
		EndDialog(hDlg, IDCANCEL);
		return TRUE;
	}
	return TRUE;
}

INT OnInitDialogConnectDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	hWndSerial = CreateDialog(g_hInst, MAKEINTRESOURCE(IDD_DIALOG_SERIAL), hDlg, (DLGPROC)SerialDlgProc);
	SetWindowPos(hWndSerial, NULL, 0, 50, 0, 0, SWP_NOSIZE | SWP_NOZORDER);
	//SetWindowPos(GetDlgItem(hWndSerial, IDD_DIALOG_SERIAL), HWND_TOP, 2, 52, 0, 0, NULL);
	ShowWindow(hWndSerial, SW_HIDE);
	return TRUE;
}

INT OnCommandConnectDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	TCHAR Mes[MAX_PATH];
	INT index;
	if (IsDlgButtonChecked(hDlg, IDC_RADIO_SERIAL) == BST_CHECKED) {
		ShowWindow(hWndSerial, SW_SHOW);		
	}
	else {
		ShowWindow(hWndSerial, SW_HIDE);
	}
	switch (LOWORD(wParam)) {
	case IDOK:
		index = SerialPort.GetObjectCount();
		if (index <= SendMessage(hComboTerminal, CB_GETCOUNT, 0, 0)) {
			MessageBox(hDlg, TEXT("���̻� �͹̳��� ������ �� �����ϴ�."), TEXT("���"), MB_OK);
			EndDialog(hWndSerial, IDCANCEL);
			EndDialog(hDlg, IDCANCEL);
			return TRUE;
		}
		if (IsDlgButtonChecked(hDlg, IDC_RADIO_SERIAL) == BST_CHECKED) {			
			if (SerialPort.AddTerminal(&DCBDlgInfo, &index, Mes) != TRUE) {
				MessageBox(hDlg, TEXT("��ġ�� ������ �� �����ϴ�!!"), TEXT("���"), MB_OK);
				return TRUE;
			}
		}
		SendMessage(hCRB, WM_USER + 1, (WPARAM)1, (LPARAM)index);
		EndDialog(hWndSerial, IDOK);
		EndDialog(hDlg, IDOK);
		return TRUE;
	case IDCANCEL:
		EndDialog(hWndSerial, IDCANCEL);
		EndDialog(hDlg, IDCANCEL);
		return TRUE;
	}
	return TRUE;
}

INT OnInitDialogSerialDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	TCHAR strBuff[20];
	//1200;2400;4800;9600;19200;38400;57600;115200;230400;460800;921600;
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_PORT), CB_GETLBTEXT, 0, (LPARAM)DCBDlgInfo.portName);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("1200"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("2400"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("4800"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("9600"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("19200"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("38400"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("57600"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("115200"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("230400"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("460800"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_ADDSTRING, 0, (LPARAM)TEXT("921600"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_SETCURSEL, 3, 0); // 3��° �׸� ����
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_GETLBTEXT, 3, (LPARAM)strBuff);
	DCBDlgInfo.baudRate = atoi(strBuff);
	//5; 6; 7; 8;
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_ADDSTRING, 0, (LPARAM)TEXT("5"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_ADDSTRING, 0, (LPARAM)TEXT("6"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_ADDSTRING, 0, (LPARAM)TEXT("7"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_ADDSTRING, 0, (LPARAM)TEXT("8"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_SETCURSEL, 3, 0);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_GETLBTEXT, 3, (LPARAM)strBuff);
	DCBDlgInfo.dataBits = atoi(strBuff);
	//None;Odd;Even;
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_PB), CB_ADDSTRING, 0, (LPARAM)TEXT("None"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_PB), CB_ADDSTRING, 0, (LPARAM)TEXT("Odd"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_PB), CB_ADDSTRING, 0, (LPARAM)TEXT("Even"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_PB), CB_SETCURSEL, 0, 0);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_PB), CB_GETLBTEXT, 0, (LPARAM)strBuff);
	if (strcmp("None", strBuff) == 0) DCBDlgInfo.parity = 0;
	if (strcmp("Odd", strBuff) == 0) DCBDlgInfo.parity = 1;
	if (strcmp("Even", strBuff) == 0) DCBDlgInfo.parity = 2;
	//1; 1.5; 2;
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_SB), CB_ADDSTRING, 0, (LPARAM)TEXT("1"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_SB), CB_ADDSTRING, 0, (LPARAM)TEXT("1.5"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_SB), CB_ADDSTRING, 0, (LPARAM)TEXT("2"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_SB), CB_SETCURSEL, 0, 0);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_SB), CB_GETLBTEXT, 0, (LPARAM)strBuff);
	if (strcmp("1", strBuff) == 0) DCBDlgInfo.stopBits = 0;
	if (strcmp("1.5", strBuff) == 0) DCBDlgInfo.stopBits = 1;
	if (strcmp("2", strBuff) == 0) DCBDlgInfo.stopBits = 2;
	//None;Xon/Xoff;RTS/CTS;
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_FC), CB_ADDSTRING, 0, (LPARAM)TEXT("None"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_FC), CB_ADDSTRING, 0, (LPARAM)TEXT("Xon/Xoff"));	
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_FC), CB_ADDSTRING, 0, (LPARAM)TEXT("RTS/CTS"));
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_FC), CB_SETCURSEL, 0, 0);
	SendMessage(GetDlgItem(hDlg, IDC_COMBO_FC), CB_GETLBTEXT, 0, (LPARAM)strBuff);
	if (strcmp("None", strBuff) == 0) DCBDlgInfo.flowControl = 0;
	if (strcmp("Xon/Xoff", strBuff) == 0) DCBDlgInfo.flowControl = 1;
	if (strcmp("RTS/CTS", strBuff) == 0) DCBDlgInfo.flowControl = 2;
	DCBDlgInfo.timeout = 100;
	return TRUE;
}

INT OnCommandSerialDlgProc(HWND hDlg, WPARAM wParam, LPARAM lParam)
{
	INT index;
	TCHAR strBuff[20];	
	switch (LOWORD(wParam)) {
	case IDC_COMBO_PORT:		
		switch (HIWORD(wParam)) {
		case CBN_CLOSEUP:
		case CBN_DBLCLK:
		case CBN_DROPDOWN:
		case CBN_EDITCHANGE:
		case CBN_EDITUPDATE:
		case CBN_ERRSPACE:
			break;
		case CBN_KILLFOCUS:
			break;
		case CBN_SELCHANGE:
			index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_PORT), CB_GETCURSEL, 0, 0);
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_PORT), CB_GETLBTEXT, index, (LPARAM)DCBDlgInfo.portName);
			break;
		case CBN_SELENDCANCEL:
		case CBN_SELENDOK:
			break;
		case CBN_SETFOCUS:
			TCHAR str[MAX_PATH];
			TCHAR portN[15];
			INT cnt;
			INT cnt_port;
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_PORT), CB_RESETCONTENT, 0, 0);
			cnt_port = SerialPort.GetSerialPorts(str, sizeof(str));
			for (cnt = 0; cnt < cnt_port; cnt++) {
				if (SerialPort.GetSerialPort(portN, str, cnt) != FALSE) {
					SendMessage(GetDlgItem(hDlg, IDC_COMBO_PORT), CB_ADDSTRING, 0, (LPARAM)portN);
				}
			}
			break;	
		}
		//SetDlgItemText(hDlg, IDC_COMBO_PORT, "\\.\COM11");
		//return TRUE;
		break;
	case IDC_COMBO_BR:
		switch (HIWORD(wParam)) {
		case CBN_SELCHANGE:
			index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_GETCURSEL, 0, 0);
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_BR), CB_GETLBTEXT, index, (LPARAM)strBuff);
			DCBDlgInfo.baudRate = atoi(strBuff);
			break;		
		}
		break;
	case IDC_COMBO_DBN:
		switch (HIWORD(wParam)) {
		case CBN_SELCHANGE:
			index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_GETCURSEL, 0, 0);
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_DBN), CB_GETLBTEXT, index, (LPARAM)strBuff);
			DCBDlgInfo.dataBits = atoi(strBuff);
			break;
		}
		break;
	case IDC_COMBO_PB:
		switch (HIWORD(wParam)) {
		case CBN_SELCHANGE:
			index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_PB), CB_GETCURSEL, 0, 0);
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_PB), CB_GETLBTEXT, index, (LPARAM)strBuff);
			if (strcmp("None", strBuff) == 0) DCBDlgInfo.parity = 0;
			if (strcmp("Odd", strBuff) == 0) DCBDlgInfo.parity = 1;
			if (strcmp("Even", strBuff) == 0) DCBDlgInfo.parity = 2;
			break;
		}
		break;
	case IDC_COMBO_SB:
		switch (HIWORD(wParam)) {
		case CBN_SELCHANGE:
			index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_SB), CB_GETCURSEL, 0, 0);
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_SB), CB_GETLBTEXT, index, (LPARAM)strBuff);
			if (strcmp("1", strBuff) == 0) DCBDlgInfo.stopBits = 0;
			if (strcmp("1.5", strBuff) == 0) DCBDlgInfo.stopBits = 1;
			if (strcmp("2", strBuff) == 0) DCBDlgInfo.stopBits = 2;
			break;
		}
		break;
	case IDC_COMBO_FC:
		switch (HIWORD(wParam)) {
		case CBN_SELCHANGE:
			index = SendMessage(GetDlgItem(hDlg, IDC_COMBO_FC), CB_GETCURSEL, 0, 0);
			SendMessage(GetDlgItem(hDlg, IDC_COMBO_FC), CB_GETLBTEXT, index, (LPARAM)strBuff);
			if (strcmp("None", strBuff) == 0) DCBDlgInfo.flowControl = 0;
			if (strcmp("Xon/Xoff", strBuff) == 0) DCBDlgInfo.flowControl = 1;
			if (strcmp("RTS/CTS", strBuff) == 0) DCBDlgInfo.flowControl = 2;
			break;
		}
		break;
	}
	return TRUE;
}

