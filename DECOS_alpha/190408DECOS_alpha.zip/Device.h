#pragma once
#include <Windows.h>
//#include "SerialComm.h"
#define DEVICETYPE_MAX	30

namespace DEVICE_CONST
{
	enum dType{
		HostPC=0, Coordinator_IoT, Coordinator_IoT2, Inverter_DASS,
		etc_Device
	};
	enum tType {
		Serial=0, TCP_IP
	};
}

class Device
{
private:
	TCHAR DeviceName[MAX_PATH];
	TCHAR DeviceType[DEVICETYPE_MAX];
	BOOL Simulator;	
	TCHAR terminalType;
	TCHAR portName[MAX_PATH];
	//SerialComm *terminalSerial;
	//static INT Counter;
	/*struct tagDeviceProperties {
		TCHAR DeviceName[MAX_PATH];
		INT DeviceType;
		TCHAR TeminalType[20];
		INT TeminalID;
		TCHAR PortNum[20];
		INT ServiceType;
		INT Protocol;
		INT Version;
		INT CodingTX;
		INT CodingRX;
		INT Attribute;
		BOOL Valid;
	}DeviceProperties;*/
public:
	Device();
	Device(const TCHAR *src);
	//BOOL GetDeviceName(TCHAR *dest, const TCHAR *src, UINT SizeinBytes);
	BOOL GetDeviceName(TCHAR *dest);
	//BOOL GetDeviceType(TCHAR *dest, const TCHAR *src, UINT SizeinBytes);
	BOOL GetDeviceType(TCHAR *dest);
	BOOL GetSimulator();
	BOOL GetPortName(TCHAR *dest);
	//BOOL SetSerialCommPtr(SerialComm SerialPort);
	//BOOL SetDeviceName(TCHAR *dest, const TCHAR *src);
	BOOL SetDeviceName(const TCHAR *src);
	//BOOL SetDeviceType(TCHAR *dest, const TCHAR *src);
	BOOL SetDeviceType(const TCHAR *src);
	BOOL SetSimulator(const TCHAR *src);
	BOOL SetPortName(const TCHAR *str);
	BOOL InitPortName();
	Device * GetThisPointer();	
	~Device();
};


