#pragma once
#include <Windows.h>

//HWND hCLT;

LRESULT CALLBACK ChildLTProc(HWND, UINT, WPARAM, LPARAM);
BOOL CALLBACK SerialDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam);
BOOL CALLBACK ConnectDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam);