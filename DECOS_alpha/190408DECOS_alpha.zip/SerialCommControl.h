#pragma once
#include <Windows.h>
#include "SerialComm.h"

struct tagDCBDlgInfo {
	TCHAR portName[32 + 1];
	INT baudRate;
	TCHAR dataBits;
	TCHAR stopBits;
	TCHAR parity;
	TCHAR flowControl;
	DWORD timeout;
};

class SerialCommControl
{
private:
	struct tagTerminalInfo {
		TCHAR numberTerminals[11];
		TCHAR cntTerminal;
		TCHAR objectCount;
	}TerminalInfo;
public:
	SerialComm * Terminal[];
public:
	//SerialCommControl();
	SerialCommControl(TCHAR num);
	INT GetSerialPorts(TCHAR *dest, INT size);
	BOOL GetSerialPort(TCHAR *dest, TCHAR *src, UINT number);
	BOOL GetStrTerminals(TCHAR *dest);
	TCHAR GetTerminalCount();
	INT GetObjectCount();
	BOOL GetAvailableTerminalIndex(INT *retIndex);
	BOOL GetTerminalIndex(INT *retIndex, TCHAR *portName);
	BOOL GetTerminalDCBInfo(tagDCBDlgInfo *destDCB, INT index);
	BOOL AddTerminal(tagDCBDlgInfo *DCBDlgInfo, TCHAR *RetMes);
	BOOL AddTerminal(tagDCBDlgInfo *DCBDlgInfo, INT *retIndex, TCHAR *RetMes);
	BOOL RefreshTerminal();
	BOOL DeleteTerminals();
	BOOL DeleteTerminal(TCHAR index);
	~SerialCommControl();
};

