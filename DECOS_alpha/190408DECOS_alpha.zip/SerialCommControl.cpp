#include "SerialCommControl.h"



//SerialCommControl::SerialCommControl()
//{
//}

SerialCommControl::SerialCommControl(TCHAR num)
{
	INT cnt;
	for (cnt = 0;cnt<10; cnt++) {
		TerminalInfo.numberTerminals[cnt] = 'N';
	}
	TerminalInfo.numberTerminals[cnt] = NULL;
	TerminalInfo.cntTerminal = 0;
	TerminalInfo.objectCount = num;
	*Terminal[num];
}

INT SerialCommControl::GetSerialPorts(TCHAR *dest, INT size)
{
	TCHAR name[MAX_PATH] = "";
	INT cnt;
	INT cnt1 = 0;
	HANDLE hSerial;
	dest[0] = NULL;
	for (cnt = 1; cnt < 256 + 1; cnt++) {
		wsprintf(name, "\\\\.\\COM%d", cnt);
		hSerial = CreateFile(name, GENERIC_READ | GENERIC_WRITE, 0, 0, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, 0);
		if (hSerial == INVALID_HANDLE_VALUE) {
			;
		}
		else {
			//MessageBox(hWnd, name, TEXT("�޽��� �ڽ�"), MB_OK);
			wsprintf(name, "\\\\.\\COM%d;", cnt);
			//_itoa_s(cnt, temp, 10);
			strcat_s(dest, size, name);
			CloseHandle(hSerial);
			cnt1++;
		}
	}
	return cnt1;
}

BOOL SerialCommControl::GetSerialPort(TCHAR *dest, TCHAR *src, UINT number)
{
	INT cnt = 0;
	INT cnt1 = 0;
	if (number == 0) {
		while (src[cnt] != ';' && src[cnt] != NULL) {
			dest[cnt] = src[cnt];
			cnt++;
		}
		dest[cnt] = NULL;
		return TRUE;
	}

	for (cnt = 0; cnt != number; cnt++) {
		if (src[cnt1] == NULL) return FALSE;
		while (src[cnt1] != ';') {
			cnt1++;
		}
	}
	cnt = 0;
	cnt1++;
	if (src[cnt1] == NULL) return FALSE;
	while (src[cnt1] != ';' && src[cnt1] != NULL) {
		dest[cnt] = src[cnt1];
		cnt++;
		cnt1++;
	}
	dest[cnt] = NULL;
	return TRUE;
}

BOOL SerialCommControl::GetStrTerminals(TCHAR *dest)
{
	INT cnt;
	TCHAR str[11];
	for (cnt = 0; TerminalInfo.numberTerminals[cnt] != NULL; cnt++) {
		if (cnt >= 10) return FALSE;
		dest[cnt] = TerminalInfo.numberTerminals[cnt];
	}
	dest[cnt] = NULL;
	return TRUE;
}

TCHAR SerialCommControl::GetTerminalCount()
{
	return TerminalInfo.cntTerminal;
}

INT SerialCommControl::GetObjectCount()
{
	return TerminalInfo.objectCount;
}

BOOL SerialCommControl::GetAvailableTerminalIndex(INT *retIndex)
{
	INT cnt;
	INT cnt1;
	BOOL status;	
	status = FALSE;
	for (cnt = 0; TerminalInfo.numberTerminals[cnt] != NULL; cnt++) {
		if (TerminalInfo.numberTerminals[cnt] == 'N') {
			status = TRUE;
			*retIndex = cnt;
			break;
		}
	}
	return status;
}

BOOL SerialCommControl::GetTerminalIndex(INT *retIndex, TCHAR *portName)
{
	INT cnt;
	TCHAR strBuff[MAX_PATH] = "";
	for (cnt = 0; TerminalInfo.numberTerminals[cnt] != NULL; cnt++) {
		if (cnt > 9) return FALSE;
		if (TerminalInfo.numberTerminals[cnt] == 'Y') {
			Terminal[cnt]->GetPortName(strBuff);
			*retIndex = cnt;
			if (strcmp(strBuff, portName) == 0) return TRUE;
		}
	}
	return FALSE;
}

BOOL SerialCommControl::GetTerminalDCBInfo(tagDCBDlgInfo *destDCB, INT index)
{
	if (this->Terminal[index]->IsConnected() != TRUE) return FALSE;
	this->Terminal[index]->GetBaudRate(&destDCB->baudRate);
	this->Terminal[index]->GetDataBits(&destDCB->dataBits);
	this->Terminal[index]->GetParity(&destDCB->parity);
	this->Terminal[index]->GetStopBits(&destDCB->stopBits);
	this->Terminal[index]->GetFlowControl(&destDCB->flowControl);
	return TRUE;
}

BOOL SerialCommControl::AddTerminal(tagDCBDlgInfo *DCBDlgInfo, TCHAR *RetMes)
{
	INT numTerminal;
	GetAvailableTerminalIndex(&numTerminal);
	this->Terminal[numTerminal] = new SerialComm(DCBDlgInfo->portName, DCBDlgInfo->baudRate, DCBDlgInfo->dataBits, DCBDlgInfo->parity,
		DCBDlgInfo->stopBits, (eFlowControl)DCBDlgInfo->flowControl, DCBDlgInfo->timeout);
	if (this->Terminal[numTerminal]->Connect(RetMes) == FALSE) return FALSE;
	TerminalInfo.numberTerminals[numTerminal] = 'Y';
	TerminalInfo.cntTerminal++;
	return TRUE;
}

BOOL SerialCommControl::AddTerminal(tagDCBDlgInfo *DCBDlgInfo, INT *retIndex,TCHAR *RetMes)
{
	INT numTerminal;
	GetAvailableTerminalIndex(&numTerminal);
	this->Terminal[numTerminal] = new SerialComm(DCBDlgInfo->portName, DCBDlgInfo->baudRate, DCBDlgInfo->dataBits, DCBDlgInfo->parity,
		DCBDlgInfo->stopBits, (eFlowControl)DCBDlgInfo->flowControl, DCBDlgInfo->timeout);
	if (this->Terminal[numTerminal]->Connect(RetMes) == FALSE) return FALSE;
	TerminalInfo.numberTerminals[numTerminal] = 'Y';
	TerminalInfo.cntTerminal++;
	*retIndex = numTerminal;
	return TRUE;
}

BOOL SerialCommControl::RefreshTerminal()
{
	INT index;
	TCHAR buff[MAX_PATH];
	TCHAR retMes[MAX_PATH];
	INT length;
	for (index = 0; TerminalInfo.numberTerminals[index] != NULL; index++) {
		if (index > 9) return FALSE;
		if (TerminalInfo.numberTerminals[index] == 'Y' && Terminal[index]->Recv(buff, sizeof(buff), retMes)== -1){
			delete this->Terminal[index];
			TerminalInfo.numberTerminals[index] = 'N';
			TerminalInfo.cntTerminal--;
		}
	}
	return TRUE;
}

BOOL SerialCommControl::DeleteTerminals()
{
	INT cnt;
	for (cnt = 0; TerminalInfo.numberTerminals[cnt] != NULL; cnt++) {
		if (cnt > 9) return FALSE;
		if (TerminalInfo.numberTerminals[cnt] == 'Y') {
			//Terminal[cnt]->Close();
			delete this->Terminal[cnt];
			TerminalInfo.numberTerminals[cnt] = 'N';
		}				
	}
	TerminalInfo.cntTerminal = 0;
	return TRUE;
}

BOOL SerialCommControl::DeleteTerminal(TCHAR index)
{
	if (TerminalInfo.numberTerminals[index] != 'Y') return FALSE;
	//Terminal[index]->Close();
	delete this->Terminal[index];
	TerminalInfo.numberTerminals[index] = 'N';
	TerminalInfo.cntTerminal--;
	return TRUE;
}


SerialCommControl::~SerialCommControl()
{
	this->DeleteTerminals();
}
