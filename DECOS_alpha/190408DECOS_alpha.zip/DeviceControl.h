#pragma once
#include <Windows.h>
#include "Device.h"

class DeviceControl
{
private:	
	struct tagDeviceInfo {
		TCHAR numberDevices[11];
		TCHAR cntDevice;
		TCHAR objectCount;		
	}DeviceInfo;
public:
	Device *Dev[];
public:
	//DeviceControl();
	DeviceControl(TCHAR num);
	INT FlushBuff(TCHAR *buf, INT count);
	INT GetObjectCount();
	BOOL GetFileName(TCHAR *dest, TCHAR *src, UINT option);
	BOOL InitSetDevices(TCHAR *fileName, INT DeviceCnt);
	BOOL DeleteDevices();
	~DeviceControl();
};
