#include "Procedure_CLB.h"

extern HINSTANCE g_hInst;
extern HWND hCLT, hCLB, hCRT, hCRB;

// �޾Ʒ��� ���ϵ��� �޽��� ���ν���
LRESULT CALLBACK ChildLBProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;

	switch (iMessage) {
	case WM_CREATE:
		/*CreateWindow(TEXT("static"), TEXT("Device Type:"), WS_CHILD | WS_VISIBLE,
			10, 10, 100, 20, hWnd, (HMENU)-1, g_hInst, NULL);*/
		return 0;
	case WM_SIZE:
	case WM_COMMAND:
		return 0;
	case WM_PAINT:
		hdc = BeginPaint(hWnd, &ps);
		SetTextAlign(hdc, TA_RIGHT);
		TextOut(hdc, 120, 10, TEXT("Device Name   :"), 15);
		TextOut(hdc, 120, 30, TEXT("Device Type   :"), 15);
		TextOut(hdc, 120, 50, TEXT("Terminal Type :"), 15);
		TextOut(hdc, 120, 70, TEXT("Terminal ID   :"), 15);
		TextOut(hdc, 120, 90, TEXT("Port Number   :"), 15);
		TextOut(hdc, 120, 110, TEXT("Service Type  :"), 15);
		TextOut(hdc, 120, 130, TEXT("Protocol      :"), 15);
		TextOut(hdc, 120, 150, TEXT("Version       :"), 15);
		TextOut(hdc, 120, 170, TEXT("Coding TX     :"), 15);
		TextOut(hdc, 120, 190, TEXT("Coding RX     :"), 15);
		//TextOut(hdc, 10, 210, TEXT("Attribute :"), 15);
		EndPaint(hWnd, &ps);
		return 0;
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}