#pragma once
#include <Windows.h>

//HWND hCRB;

LRESULT CALLBACK ChildRBProc(HWND, UINT, WPARAM, LPARAM);