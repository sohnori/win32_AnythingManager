#pragma once
#include <Windows.h>

//HWND hCRT;

LRESULT CALLBACK ChildRTProc(HWND, UINT, WPARAM, LPARAM);