#pragma once
#include <Windows.h>

//HWND hCLB;

LRESULT CALLBACK ChildLBProc(HWND, UINT, WPARAM, LPARAM);