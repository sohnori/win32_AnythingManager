#include "Procedure_CRB.h"
#include <stdio.h>
#include <CommCtrl.h>
#include "SerialComm.h"
#include "SerialCommControl.h"
#include "MyFunc.h"
#include "Device.h"
#include "DeviceControl.h"

extern HINSTANCE g_hInst;

extern DeviceControl Device;
extern SerialCommControl SerialPort;

static HWND hLogEdit[10];
static HWND hCmdEdit, hTab;
static HWND hGroup1, hGroup2, hR1, hR2, hCK1, hCK2, hCK3, hCK4, hBtn1, hBtn2, hR3, hR4, hBtn3;

extern TCHAR rxBuff[1024];
extern DWORD dwBytesRead;
extern TCHAR txBuff[1024];
extern INT dwBytesWrite;


INT OnCreateChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnCommandChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnNotifyChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnSizeChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnUser1ChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnUser2ChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam);
INT OnPaintChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam);

// �����Ʒ��� ���ϵ��� �޽��� ���ν���
LRESULT CALLBACK ChildRBProc(HWND hWnd, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	switch (iMessage) {
	case WM_CREATE: OnCreateChildRBProc(hWnd, wParam, lParam); return 0;	
	case WM_COMMAND:OnCommandChildRBProc(hWnd, wParam, lParam); break;
	case WM_NOTIFY:	OnNotifyChildRBProc(hWnd, wParam, lParam); return 0;
	case WM_SIZE: OnSizeChildRBProc(hWnd, wParam, lParam); return 0;
	case WM_USER+1: OnUser1ChildRBProc(hWnd, wParam, lParam); return 0;
	case WM_USER+2:	OnUser2ChildRBProc(hWnd, wParam, lParam); return 0;
	case WM_PAINT: OnPaintChildRBProc(hWnd, wParam, lParam); return 0;	
	}
	return(DefWindowProc(hWnd, iMessage, wParam, lParam));
}

INT OnCreateChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	TCITEM tie;
	hLogEdit[0] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[1] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[2] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[3] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[4] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[5] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[6] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[7] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[8] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hLogEdit[9] = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_MULTILINE | WS_VSCROLL | WS_HSCROLL,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);

	//SetWindowText(hLogEdit0, TEXT("����Ʈ ������0�Դϴ�."));		
	//InitCommonControls();
	hTab = CreateWindow(WC_TABCONTROL, "", WS_CHILD | WS_VISIBLE | WS_CLIPSIBLINGS | TCS_FORCELABELLEFT,
		0, 0, 0, 0, hWnd, (HMENU)0, g_hInst, NULL);

	hGroup1 = CreateWindow(TEXT("button"), TEXT("ǥ��â :"), WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hR1 = CreateWindow(TEXT("button"), TEXT("HEX"), WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hR2 = CreateWindow(TEXT("button"), TEXT("ASCII"), WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hCK1 = CreateWindow(TEXT("button"), TEXT("Send ǥ��"), WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hCK2 = CreateWindow(TEXT("button"), TEXT("Receive ǥ��"), WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hCK3 = CreateWindow(TEXT("button"), TEXT("�ڵ��ٹٲ�"), WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hBtn1 = CreateWindow(TEXT("button"), TEXT("����"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		0, 0, 0, 0, hWnd, (HMENU)1, g_hInst, NULL);
	hBtn2 = CreateWindow(TEXT("button"), TEXT("����"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		0, 0, 0, 0, hWnd, (HMENU)2, g_hInst, NULL);

	hGroup2 = CreateWindow(TEXT("button"), TEXT("����â :"), WS_CHILD | WS_VISIBLE | BS_GROUPBOX,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hCmdEdit = CreateWindow(TEXT("edit"), NULL, WS_CHILD | WS_VISIBLE | WS_BORDER | ES_AUTOHSCROLL,
		0, 0, 0, 0, hWnd, (HMENU)10, g_hInst, NULL);
	hR3 = CreateWindow(TEXT("button"), TEXT("HEX"), WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON | WS_GROUP,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hR4 = CreateWindow(TEXT("button"), TEXT("ASCII"), WS_CHILD | WS_VISIBLE | BS_AUTORADIOBUTTON,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hCK4 = CreateWindow(TEXT("button"), TEXT("\\r �ڵ�����"), WS_CHILD | WS_VISIBLE | BS_AUTOCHECKBOX,
		0, 0, 0, 0, hWnd, NULL, g_hInst, NULL);
	hBtn3 = CreateWindow(TEXT("button"), TEXT("������"), WS_CHILD | WS_VISIBLE | BS_PUSHBUTTON,
		0, 0, 0, 0, hWnd, (HMENU)3, g_hInst, NULL);

	SendMessage(hCK1, BM_SETCHECK, BST_CHECKED, 0);
	SendMessage(hCK2, BM_SETCHECK, BST_CHECKED, 0);
	SendMessage(hR2, BM_SETCHECK, BST_CHECKED, 0);
	SendMessage(hR4, BM_SETCHECK, BST_CHECKED, 0);
	tie.mask = TCIF_TEXT;
	tie.pszText = (LPSTR)("HostPC");
	TabCtrl_InsertItem(hTab, 0, &tie);
	/*tie.pszText = (LPSTR)("two");
	TabCtrl_InsertItem(hTab, 1, &tie);
	tie.pszText = (LPSTR)("three");
	TabCtrl_InsertItem(hTab, 2, &tie);*/
	ShowWindow(hLogEdit[1], SW_HIDE);
	ShowWindow(hLogEdit[2], SW_HIDE);
	ShowWindow(hLogEdit[3], SW_HIDE);
	ShowWindow(hLogEdit[4], SW_HIDE);
	ShowWindow(hLogEdit[5], SW_HIDE);
	ShowWindow(hLogEdit[6], SW_HIDE);
	ShowWindow(hLogEdit[7], SW_HIDE);
	ShowWindow(hLogEdit[8], SW_HIDE);
	ShowWindow(hLogEdit[9], SW_HIDE);
	return 0;
}

INT OnCommandChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{	
	TCITEM tie;
	INT cnt = 0;
	TCHAR *rxHEXBuff = (TCHAR*)malloc(1024);
	INT length;
	INT index;
	INT indexSerial;	
	TCHAR strBuff[MAX_PATH];
	TCHAR retMes[MAX_PATH];
	TCHAR tabName[20];
	RECT rt;
	switch (LOWORD(wParam)) {
	case 0:
		break;
	case 1: // ���� ��ư ����
		break;
	case 2: // ���� ��ư ����
		index = TabCtrl_GetCurSel(hTab);
		SendMessage(hLogEdit[index], EM_SETSEL, 0, -1);
		SendMessage(hLogEdit[index], WM_CLEAR, 0, 0);		
		break;
	case 3: // ���� ������ ��ư ����
		// ����â�� �Է� ������ ���۷� �о��� �ش� ��ġ�� ������ ��� ���ο� ���� ����Ʈ â�� ����Ѵ�.		
		//cnt = SendMessage(hCmdEdit, EM_GETLINE, (WPARAM)0, (LPARAM)strBuff);
		cnt = SendMessage(hCmdEdit, WM_GETTEXT, (WPARAM)128, (LPARAM)strBuff);
		if(SendMessage(hCK4, BM_GETCHECK, 0, 0)!=BST_CHECKED) strBuff[cnt] = NULL;
		else { strBuff[cnt] = '\r'; strBuff[cnt + 1] = NULL; }
		// // ����â 16���� �� �Է� ���� üũ�ڽ� Ȯ�� �� TRUE�̸� ���ڿ��� ��� �迭�� hex ������ ��ȯ ����
		if (SendMessage(hR3, BM_GETCHECK, 0, 0) == BST_CHECKED) cnt = AsciiHextoHarr(rxHEXBuff, strBuff, cnt);		
		SendMessage(hCmdEdit, EM_SETSEL, 0, -1);
		SendMessage(hCmdEdit, WM_CLEAR, 0, 0);
		// ������Ƽ ��Ʈ �� ���� �б�
		tie.mask = TCIF_TEXT;
		tie.pszText = tabName;
		tie.cchTextMax = sizeof(tabName);
		index = TabCtrl_GetCurSel(hTab);
		if (index == -1) break;
		TabCtrl_GetItem(hTab, index, &tie);
		// �ø��� ��Ʈ ��ȿ�� Ȯ�� �ƴϸ� �극��ũ
		if (SerialPort.GetTerminalIndex(&indexSerial, tie.pszText) != TRUE) break;

		if (SendMessage(hR3, BM_GETCHECK, 0, 0) == BST_CHECKED) {
			// ����â 16���� �� �Է� ���� üũ�ڽ� Ȯ��
			cnt = SerialPort.Terminal[indexSerial]->Send(rxHEXBuff, lstrlen(rxHEXBuff), retMes);
		}
		else {
			cnt = SerialPort.Terminal[indexSerial]->Send(strBuff, lstrlen(strBuff), retMes);
		}
		
		if (SendMessage(hCK1, BM_GETCHECK, 0, 0) == BST_UNCHECKED) break; // send ǥ�� ����
		if (SendMessage(hR3, BM_GETCHECK, 0, 0) == BST_CHECKED) { // hex ������ ��� üũ ���� Ȯ��
			// hex ������ ��̿� ����� �����͸� ���ڿ�ȭ �Ͽ� ����Ʈ â�� ����Ѵ�.
			cnt = AtoHstr(strBuff, rxHEXBuff, cnt);
			if (SendMessage(hCK3, BM_GETCHECK, 0, 0) == BST_CHECKED)//strcat_s(rxHEXBuff, 2, "\r\n");
			{				
				*(strBuff + cnt) = '\r';
				*(strBuff + cnt + 1) = '\n';
				*(strBuff + cnt + 2) = NULL;
			}
			length = GetWindowTextLength(hLogEdit[0]);
			SendMessage(hLogEdit[0], EM_SETSEL, length, length);
			SendMessage(hLogEdit[0], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)strBuff);
			length = GetWindowTextLength(hLogEdit[index]);
			SendMessage(hLogEdit[index], EM_SETSEL, length, length);
			SendMessage(hLogEdit[index], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)strBuff);
		}
		else {
			// ���ڿ� ���� ����Ʈ â�� ����Ѵ�.
			if (SendMessage(hCK3, BM_GETCHECK, 0, 0) == BST_CHECKED) strcat_s(strBuff, "\r\n");
			length = GetWindowTextLength(hLogEdit[0]);
			SendMessage(hLogEdit[0], EM_SETSEL, length, length);
			SendMessage(hLogEdit[0], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)strBuff);
			length = GetWindowTextLength(hLogEdit[index]);
			SendMessage(hLogEdit[index], EM_SETSEL, length, length);
			SendMessage(hLogEdit[index], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)strBuff);
		}					
		break;
	case 10:
		switch (HIWORD(wParam)) {
		case EN_SETFOCUS:
			//SetFocus(hBtn3);
//			DrawFocusRect(hdc, &rt);
			break;
		}
		break;
	case 11:
		// ����â�� �Է� ������ ���۷� �о��� �ش� ��ġ�� ������ ��� ���ο� ���� ����Ʈ â�� ����Ѵ�.
		CopyData(strBuff, txBuff, dwBytesWrite);
		strBuff[dwBytesWrite] = NULL;			
		// ������Ƽ ��Ʈ �� ���� �б�
		tie.mask = TCIF_TEXT;
		tie.pszText = tabName;
		tie.cchTextMax = sizeof(tabName);
		index = TabCtrl_GetCurSel(hTab);
		if (index == -1) break;
		TabCtrl_GetItem(hTab, index, &tie);
		// �ø��� ��Ʈ ��ȿ�� Ȯ�� �ƴϸ� �극��ũ
		if (SerialPort.GetTerminalIndex(&indexSerial, tie.pszText) != TRUE) break;
			
		if (SendMessage(hCK1, BM_GETCHECK, 0, 0) == BST_UNCHECKED) break; // send ǥ�� ����

		if (SendMessage(hR3, BM_GETCHECK, 0, 0) == BST_CHECKED) { // hex ������ ��� üũ ���� Ȯ��
			// hex ������ ��̿� ����� �����͸� ���ڿ�ȭ �Ͽ� ����Ʈ â�� ����Ѵ�.
			cnt = AtoHstr(rxHEXBuff, strBuff, dwBytesWrite);
			if (SendMessage(hCK3, BM_GETCHECK, 0, 0) == BST_CHECKED)//strcat_s(rxHEXBuff, 2, "\r\n");
			{				
				*(rxHEXBuff + cnt) = '\r';
				*(rxHEXBuff + cnt + 1) = '\n';
				*(rxHEXBuff + cnt + 2) = NULL;
			}
			length = GetWindowTextLength(hLogEdit[0]);
			SendMessage(hLogEdit[0], EM_SETSEL, length, length);
			SendMessage(hLogEdit[0], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)rxHEXBuff);
			length = GetWindowTextLength(hLogEdit[index]);
			SendMessage(hLogEdit[index], EM_SETSEL, length, length);
			SendMessage(hLogEdit[index], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)rxHEXBuff);
		}
		else {
			// ���ڿ� ���� ����Ʈ â�� ����Ѵ�.
			if (SendMessage(hCK3, BM_GETCHECK, 0, 0) == BST_CHECKED) strcat_s(strBuff, "\r\n");
			length = GetWindowTextLength(hLogEdit[0]);
			SendMessage(hLogEdit[0], EM_SETSEL, length, length);
			SendMessage(hLogEdit[0], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)strBuff);
			length = GetWindowTextLength(hLogEdit[index]);
			SendMessage(hLogEdit[index], EM_SETSEL, length, length);
			SendMessage(hLogEdit[index], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)strBuff);
		}					
		break;
	}
	free(rxHEXBuff);
	return 0;
}

INT OnNotifyChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	INT index;
	INT cnt;
	switch (((LPNMHDR)lParam)->code) {
	case TCN_SELCHANGE:
		//SetWindowText(hStatic, arNum[TabCtrl_GetCurSel(hTab)]);
		index = TabCtrl_GetCurSel(hTab);
		for (cnt = 0; cnt < 10; cnt++) {
			if (cnt==index) ShowWindow(hLogEdit[cnt], SW_SHOW);
			else ShowWindow(hLogEdit[cnt], SW_HIDE);
		}		
		/*if(IsWindowVisible(hLogEdit1)==TRUE) ShowWindow(hLogEdit1, SW_HIDE);
		else ShowWindow(hLogEdit1, SW_SHOW);*/
		break;
	}
	return 0;
}

INT OnSizeChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	INT index;
	INT cnt;
	MoveWindow(hTab, 0, 0, LOWORD(lParam), HIWORD(lParam) - 175, TRUE);
	MoveWindow(hLogEdit[0], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[1], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[2], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[3], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[4], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[5], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[6], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[7], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[8], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	MoveWindow(hLogEdit[9], 5, 25, LOWORD(lParam) - 20, HIWORD(lParam) - 200, TRUE);
	
	MoveWindow(hGroup1, 5, HIWORD(lParam) - 175, LOWORD(lParam) - 20, 40, TRUE);
	MoveWindow(hR1, 95, HIWORD(lParam) - 160, 50, 20, TRUE);
	MoveWindow(hR2, 155, HIWORD(lParam) - 160, 60, 20, TRUE);
	MoveWindow(hCK1, 250, HIWORD(lParam) - 160, 90, 20, TRUE);
	MoveWindow(hCK2, 350, HIWORD(lParam) - 160, 120, 20, TRUE);
	MoveWindow(hCK3, 480, HIWORD(lParam) - 160, 100, 20, TRUE);
	MoveWindow(hBtn1, 660, HIWORD(lParam) - 160, 70, 20, TRUE);
	MoveWindow(hBtn2, 740, HIWORD(lParam) - 160, 70, 20, TRUE);

	MoveWindow(hGroup2, 5, HIWORD(lParam) - 130, LOWORD(lParam) - 20, 80, TRUE);
	MoveWindow(hCmdEdit, 10, HIWORD(lParam) - 100, LOWORD(lParam) - 30, 20, TRUE);
	MoveWindow(hR3, 95, HIWORD(lParam) - 75, 50, 20, TRUE);
	MoveWindow(hR4, 155, HIWORD(lParam) - 75, 60, 20, TRUE);
	MoveWindow(hCK4, 250, HIWORD(lParam) - 75, 100, 20, TRUE);
	MoveWindow(hBtn3, 740, HIWORD(lParam) - 75, 70, 20, TRUE);
	//InvalidateRect(hWnd, NULL, TRUE);
	index = TabCtrl_GetCurSel(hTab);
	for (cnt = 0; cnt < 10; cnt++) {
		if (cnt == index) ShowWindow(hLogEdit[cnt], SW_SHOW);
		else ShowWindow(hLogEdit[cnt], SW_HIDE);
	}
	return 0;
}

INT OnUser1ChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	TCHAR str[MAX_PATH];
	TCHAR index = (TCHAR)lParam;
	TCITEM tie;
	switch (LOWORD(wParam)) {
	case 1: // Ȱ��ȭ�� ��Ʈ�� �ش��ϴ� �� �߰�
		SerialPort.Terminal[index]->GetPortName(str);
		tie.mask = TCIF_TEXT;
		tie.pszText = (LPSTR)(str);
		TabCtrl_InsertItem(hTab, index + 1, &tie);
		break;
	case 2: // �� ����
		TabCtrl_DeleteItem(hTab, index + 1);
		break;
	}
	return 0;
}

INT OnUser2ChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{ // �α� ����Ʈ â�� ���� �����͸� ����Ѵ�.
	INT cnt;
	INT length;
	INT index = (INT)(LOWORD(wParam));	
	TCHAR *rxHEXBuff = (TCHAR *)malloc(1024);

	if (SendMessage(hCK2, BM_GETCHECK, 0, 0) == BST_UNCHECKED) {
		// receive ǥ�� ��� ����
		free(rxHEXBuff);
		return 0;
	}
	if (SendMessage(hR1, BM_GETCHECK, 0, 0) == BST_CHECKED) {
		// �ø��� �Է� ���� ���� hex �� ���ڿ��� ��ȯ �� ���
		cnt = AtoHstr(rxHEXBuff, rxBuff, dwBytesRead);
		if (SendMessage(hCK3, BM_GETCHECK, 0, 0) == BST_CHECKED)
		{
			cnt = lstrlen(rxHEXBuff);
			*(rxHEXBuff + cnt) = '\r';
			*(rxHEXBuff + cnt + 1) = '\n';
			*(rxHEXBuff + cnt + 2) = NULL;
		}
		length = GetWindowTextLength(hLogEdit[0]);
		SendMessage(hLogEdit[0], EM_SETSEL, length, length);
		SendMessage(hLogEdit[0], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)rxHEXBuff);
		length = GetWindowTextLength(hLogEdit[index]);
		SendMessage(hLogEdit[index], EM_SETSEL, length, length);
		SendMessage(hLogEdit[index], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)rxHEXBuff);		
	}
	else {
		// �ø��� �Է� ���� ���� ���ڿ��� ���
		if (SendMessage(hCK3, BM_GETCHECK, 0, 0) == BST_CHECKED) strcat_s(rxBuff, "\r\n");
		length = GetWindowTextLength(hLogEdit[0]);
		SendMessage(hLogEdit[0], EM_SETSEL, length, length);
		SendMessage(hLogEdit[0], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)rxBuff);
		length = GetWindowTextLength(hLogEdit[index]);
		SendMessage(hLogEdit[index], EM_SETSEL, length, length);
		SendMessage(hLogEdit[index], EM_REPLACESEL, (WPARAM)TRUE, (LPARAM)rxBuff);
	}
	free(rxHEXBuff);
	return 0;
}

INT OnPaintChildRBProc(HWND hWnd, WPARAM wParam, LPARAM lParam)
{
	HDC hdc;
	PAINTSTRUCT ps;
	//HBRUSH MyBrush, OldBrush;
	hdc = BeginPaint(hWnd, &ps);
	//MyBrush = (HBRUSH)GetStockObject(LTGRAY_BRUSH);
	//MyBrush = CreateSolidBrush(RGB(128, 128, 128));
	//OldBrush = (HBRUSH)SelectObject(hdc, MyBrush);	
	//SelectObject(hdc, OldBrush);
	//DeleteObject(MyBrush);
	EndPaint(hWnd, &ps);
	return 0;
}