#include "DeviceControl.h"



//DeviceControl::DeviceControl()
//{
//
//}

DeviceControl::DeviceControl(TCHAR num)
{
	INT cnt;	
	for (cnt = 0; cnt < 10; cnt++) 	{
		this->DeviceInfo.numberDevices[cnt] = 'N'; 
	}
	this->DeviceInfo.numberDevices[cnt] = NULL;
	this->DeviceInfo.cntDevice = 0;
	this->DeviceInfo.objectCount = num;
	*Dev[num];
}

INT DeviceControl::FlushBuff(TCHAR *buf, INT count)
{
	int cnt;
	if (count > 1024) return -1;
	for (cnt = 0; cnt < count; cnt++) {
		buf[cnt] = NULL;
	}
	return cnt;
}

INT DeviceControl::GetObjectCount()
{
	return this->DeviceInfo.objectCount;
}

BOOL DeviceControl::GetFileName(TCHAR *dest, TCHAR *src, UINT option)
{
	INT cnt;
	INT cnt1 = 0;
	if (option == 0) {
		for (; src[cnt1] != ';'; cnt1++) {
			if (src[cnt1] == NULL) return FALSE;
			if (cnt1 >= MAX_PATH) return FALSE;
			dest[cnt1] = src[cnt1];
		}
		dest[cnt1] = NULL;
		return TRUE;
	}

	for (cnt = 0; cnt < option; cnt++) {
		if (option > 10) return FALSE;
		if (cnt1 >= MAX_PATH) return FALSE;
		for (; src[cnt1] != ';'; cnt1++) if (src[cnt1] == NULL) return FALSE;

		cnt1++;
	}
	cnt = 0;
	for (; src[cnt1] != ';'; cnt1++) {
		if (src[cnt1] == NULL) return FALSE;
		if (cnt >= (MAX_PATH - 1)) break;
		dest[cnt] = src[cnt1];
		cnt++;
	}
	dest[cnt] = NULL;
	return TRUE;
}

BOOL DeviceControl::InitSetDevices(TCHAR *fileName, INT DeviceCnt)
{
	INT cnt1;
	DWORD dwRead;
	HANDLE hFile;
	TCHAR buf[1024];
	TCHAR str[MAX_PATH];
	for (cnt1 = 0; cnt1 < DeviceCnt; cnt1++) {
		if (cnt1 > this->DeviceInfo.objectCount) return FALSE;
		this->GetFileName(str, fileName, cnt1);
		hFile = CreateFile(str, GENERIC_READ, 0, NULL, OPEN_EXISTING, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE) {
			ReadFile(hFile, buf, sizeof(buf), &dwRead, NULL);
			this->Dev[cnt1] = new Device(buf);
			//this->Dev[cnt1] = new Device();
			//this->Dev[cnt1]->SetDeviceName(buf);
			//this->Dev[cnt1]->SetDeviceType(buf);
			//this->Dev[cnt1]->SetSimulator(buf);
			//SendMessage(hList, LB_ADDSTRING, 0, (LPARAM)buf);
			this->DeviceInfo.numberDevices[cnt1] = 'Y';
			CloseHandle(hFile);
			FlushBuff(buf, sizeof(buf));
		}
		else {
			CloseHandle(hFile);
		}
	}	
	this->DeviceInfo.cntDevice = DeviceCnt;
	return TRUE;
}

BOOL DeviceControl::DeleteDevices()
{
	INT cnt;
	for (cnt = 0; this->DeviceInfo.numberDevices[cnt] != NULL; cnt++) {		
		if (this->DeviceInfo.numberDevices[cnt] == 'Y') {
			delete this->Dev[cnt];
			this->DeviceInfo.numberDevices[cnt] = 'N';
		}
	}
	this->DeviceInfo.cntDevice = 0;
	return TRUE;
}


DeviceControl::~DeviceControl()
{
	this->DeleteDevices();
}
